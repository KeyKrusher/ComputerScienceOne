//
//  ViewController.swift
//  FizzBuzz
//
//  Created by period2 on 11/15/16.
//  Copyright © 2016 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var textField1: UITextField!
    
    
    @IBOutlet weak var textField2: UITextField!
    
    @IBOutlet weak var fizzBuzzLabel: UILabel!

    @IBAction func multiplyOnTap(sender: UIButton) {
        let a = Int(textField1.text!)!
        let b = Int(textField2.text!)!
        let product = a * b
        print(product)
        
        
    
        func fizzBuzzLogic(product:Int){
            if product % 15 == 0
            {
                fizzBuzzLabel.text = "fizzBuzz"
            }
            else if product % 5 == 0
            {
                fizzBuzzLabel.text = "Buzz"
            }
            else if product % 3 == 0
            {
                
                fizzBuzzLabel.text = "Fizz"
            
            }
            else
            {
                fizzBuzzLabel.text = ""
                
            }
        
        
        }
        
        
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

