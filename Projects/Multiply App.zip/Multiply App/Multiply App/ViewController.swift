//
//  ViewController.swift
//  Multiply App
//
//  Created by period2 on 10/17/16.
//  Copyright © 2016 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var answerLabel: UILabel!
   
    @IBOutlet weak var textFieldOne: UITextField!
    
    @IBOutlet weak var textFieldTwo: UITextField!
    
    
    
    
    
    
    var multiplyStr:String = ""
    var divideStr:String = ""
    var subtractStr:String = ""
    var addStr:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }


    @IBAction func multiplyOnTap(sender: UIButton) {
        textFieldOne.resignFirstResponder()
        textFieldTwo.resignFirstResponder()
        let number1 = Int(textFieldOne.text!)
        let number2 = Int(textFieldTwo.text!)
        let multiplyStr = number1! * number2!
        answerLabel.text = "= \(multiplyStr)"
    }
    
    @IBAction func DivideOnTap(sender: UIButton)
    {
        textFieldOne.resignFirstResponder()
        textFieldTwo.resignFirstResponder()
        let number1 = Int(textFieldOne.text!)
        let number2 = Int(textFieldTwo.text!)
        let divideStr = number1! / number2!
        answerLabel.text = "= \(divideStr)"
    }
    
    @IBAction func addOnTap(sender: UIButton) {
    textFieldOne.resignFirstResponder()
    textFieldTwo.resignFirstResponder()
    let number1 = Int(textFieldOne.text!)
    let number2 = Int(textFieldTwo.text!)
    let addStr = number1! + number2!
        answerLabel.text = "= \(addStr)"
    }
    
    @IBAction func SubtractOnTap(sender: UIButton) {
        textFieldOne.resignFirstResponder()
        textFieldTwo.resignFirstResponder()
        let number1 = Int(textFieldOne.text!)
        let number2 = Int(textFieldTwo.text!)
        let SubtractStr = number1! - number2!
        answerLabel.text = "= \(SubtractStr)"
    }
    
    
}


