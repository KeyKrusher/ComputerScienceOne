//
//  ViewController.swift
//  TipCalculator
//
//  Created by period2 on 11/28/16.
//  Copyright © 2016 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var billTotal: UITextField!
    @IBOutlet weak var tipAmount: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "orange_bg")!)
       
    }
    var multiplyStr:String = ""
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    @IBAction func calculateOnTap(sender: UIButton) {
    billTotal.resignFirstResponder()
        tipAmount.resignFirstResponder()
        let number1 = Double(billTotal.text!)!
        let multiplyStr = number1 * 0.15
        tipAmount.text = "$" + "\(multiplyStr)"
    }


}

