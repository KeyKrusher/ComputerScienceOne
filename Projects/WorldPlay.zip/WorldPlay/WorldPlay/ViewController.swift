//
//  ViewController.swift
//  WorldPlay
//
//  Created by period2 on 1/9/17.
//  Copyright © 2017 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nounField: UITextField!
    
    var myWords = Words()
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let libs = segue.destinationViewController as! VerbViewController
        
        libs.myWords2 = myWords
        myWords.noun = nounField.text!
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

