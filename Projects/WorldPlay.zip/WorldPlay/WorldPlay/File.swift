//
//  File.swift
//  WorldPlay
//
//  Created by period2 on 1/10/17.
//  Copyright © 2017 period2. All rights reserved.
//

import Foundation

class Words {
    var noun = ""
    var verb = ""
    var adjective = ""
}