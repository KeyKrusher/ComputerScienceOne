//
//  LastViewController.swift
//  WorldPlay
//
//  Created by period2 on 1/10/17.
//  Copyright © 2017 period2. All rights reserved.
//

import UIKit

class LastViewController: UIViewController {

    @IBOutlet weak var myTextView: UITextView!
    
    var myWords4 = Words()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        myTextView.text = "There once was a \(myWords4.noun) who could \(myWords4.verb) all day with his \(myWords4.adjective) dog."
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
