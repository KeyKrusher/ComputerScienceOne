//
//  AdjectiveViewController.swift
//  WorldPlay
//
//  Created by period2 on 1/10/17.
//  Copyright © 2017 period2. All rights reserved.
//

import UIKit

class AdjectiveViewController: UIViewController {
    
    @IBOutlet weak var adjectiveField: UITextField!

    var myWords3 = Words()
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let libs = segue.destinationViewController as! LastViewController
        
        libs.myWords4 = myWords3
        myWords3.adjective = adjectiveField.text!
    
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
