//
//  ViewController.swift
//  HelloWorld
//
//  Created by period2 on 9/26/16.
//  Copyright © 2016 period2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        favoriteClassLabel.text = "Science"
    }

   
    
    @IBOutlet weak var favoriteClassLabel: UILabel!
    
    @IBAction func yellowButton(sender: AnyObject) {
    }
    


}

